﻿using Dal.Entities.Concrete;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Text;

namespace Dal.Entities.Context
{
    public class PharmacyAutomationSystemContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(@"Server=DESKTOP-2LQSQ9O;Database=PharmacyAutomationSystem;Integrated Security=true",

                options =>
                {
                    options.EnableRetryOnFailure();
                    options.CommandTimeout(300);
                    options.MaxBatchSize(Int32.MaxValue);
                });
            }
        }
        public DbSet<Medicine> TBL_Medicine { get; set; }
        public DbSet<Admin> TBL_Admin { get; set; }


    }
}
