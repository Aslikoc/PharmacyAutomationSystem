﻿using Dal.Entities.Concrete;
using Dal.Entities.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dal.DbOps
{
    public class MedicineDB
    {

        private static MedicineDB _instance;
        private MedicineDB()
        {

        }
        public static MedicineDB GetInstance()
        {
            return _instance ?? new MedicineDB();
        }
        public Medicine AddMedicine(Medicine _medicine)
        {
            try
            {
                using (var context = new PharmacyAutomationSystemContext())
                {
                    context.TBL_Medicine.Add(_medicine);
                    var numberOfAdded = context.SaveChanges();
                    return numberOfAdded > 0 ? _medicine : null;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<Medicine> GetMedicineList()
        {
            try
            {
                using (var context = new PharmacyAutomationSystemContext())
                {
                    var medicineList = context.TBL_Medicine.ToList();
                    return medicineList;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public bool UpdateMedicine(Medicine _medicine)
        {
            try
            {
                using (var context = new PharmacyAutomationSystemContext())
                {
                    context.TBL_Medicine.Update(_medicine);
                    var numberOfAdded = context.SaveChanges();
                    return numberOfAdded > 0 ? true : false;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        public bool DeleteMedicine(Medicine _medicine)
        {
            try
            {
                using (var context = new PharmacyAutomationSystemContext())
                {
                    context.TBL_Medicine.Remove(_medicine);
                    var numberOfAdded = context.SaveChanges();
                    return numberOfAdded > 0 ? true : false;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        public Medicine GetMedicineById(int _id)
        {
            try
            {
                using (var context = new PharmacyAutomationSystemContext())
                {
                    var medicine = context.TBL_Medicine.FirstOrDefault(x => x.Id == _id);

                    return medicine;
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }
    }
}
