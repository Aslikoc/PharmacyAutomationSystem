﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dal.DbOps
{
   public class AdminDB
    {
        private static AdminDB _instance;
        private AdminDB()
        {

        }
        public static AdminDB GetInstance()
        {
            return _instance ?? new AdminDB();
        }
    }
}
