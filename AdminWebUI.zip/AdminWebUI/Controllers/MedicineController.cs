﻿
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AdminWebUI.Models;

namespace AdminWebUI.Controllers
{
    public class MedicineController : Controller
    {
        public IActionResult Index()
        {
            var url = $"https://localhost:44353/MedicineService/GetMedicineList";
            var paramList = new List<ServiceParameterObject>();

            var apiResult = ApiResult.SendPostRequestFromBody(url, paramList);

            if (apiResult.Status)
            {
                var deserialiazed = JsonConvert.DeserializeObject<List<Medicine>>(apiResult.Message);

                return View(deserialiazed);
            }

            else
            {
                return View(new List<Medicine>());
            }
        }



        public JsonResult AddNewMedicine(int _id,string _name,string _description,string _image,string _type,int _stock, int _price)
        {//addnewmedicine olcak ama bakalım 
            var medicine = new Medicine()
            {
                Id = _id,
                Name = _name,
                Description = _description,
                Image = _image,
                Type=_type,
                Stock=_stock,
                Price=_price


            };

            var url = $"https://localhost:44353/MedicineService/AddMedicine";
            var paramList = new List<ServiceParameterObject>();

            paramList.Add(new ServiceParameterObject("_medicine", JsonConvert.SerializeObject(medicine)));

            var apiResult = ApiResult.SendPostRequestFromBody(url, paramList);


            return Json(apiResult.Status);


        }

        public JsonResult DeleteMedicine(int _id)
        {
            var medicine = new Medicine()
            {Id = _id
            };

            var url = $"https://localhost:44353/MedicineService/DeleteMedicine";
            var paramList = new List<ServiceParameterObject>();

            paramList.Add(new ServiceParameterObject("_medicine", JsonConvert.SerializeObject(medicine)));

            var apiResult = ApiResult.SendPostRequestFromBody(url, paramList);


            return Json(apiResult.Status);


        }


        public JsonResult UpdateMedicine(Medicine _medicine)
        {
            var medicine = new Medicine()
            {
                Id = _medicine.Id,
                Name = _medicine.Name,
                Description = _medicine.Description,
                Image = _medicine.Image,
                Type = _medicine.Type,
                Stock = _medicine.Stock,
                Price = _medicine.Price


            };

            var url = $"https://localhost:44353/MedicineService/UpdateMedicine";
            var paramList = new List<ServiceParameterObject>();

            paramList.Add(new ServiceParameterObject("_medicine", JsonConvert.SerializeObject(medicine)));

            var apiResult = ApiResult.SendPostRequestFromBody(url, paramList);


            return Json(apiResult.Status);


        }

        public JsonResult GetMedicineById(int _id)
        {
            var medicine = new Medicine()
            {
                Id = _id

            };
            var url = $"https://localhost:44353/MedicineService/GetMedicineById";
            var paramList = new List<ServiceParameterObject>();
            paramList.Add(new ServiceParameterObject("_id", _id.ToString()));

            var apiResult = ApiResult.SendPostRequestFromBody(url, paramList);

            if (apiResult.Status)
            {
                var deserialized = JsonConvert.DeserializeObject<Medicine>(apiResult.Message);
                return Json(deserialized);
            }
            else
            {
                return Json(false);
            }
        }

    }
}
